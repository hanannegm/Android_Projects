package com.example.heba.fragmentexample;

/**
 * Created by heba on 12/5/2016.
 */

public interface SubjectListListener {
    public void onItemClick(int id);
}
